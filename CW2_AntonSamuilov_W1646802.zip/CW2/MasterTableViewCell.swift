//
//  MasterTableViewCell.swift
//  CW2
//
//  Created by Anton Samuilov on 25/05/2020.
//  Copyright © 2020 Anton Samuilov. All rights reserved.
//

import UIKit

class MasterTableViewCell: UITableViewCell {

    @IBOutlet weak var marksAcheived: UILabel!
    
    @IBOutlet weak var valueOfModule: UILabel!
    @IBOutlet weak var assesmentName: UILabel!
    @IBOutlet weak var moduleName: UILabel!
}
