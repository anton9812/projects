//
//  dayLeftToComplete.swift
//  CW2
//
//  Created by Anton Samuilov on 19/05/2020.
//  Copyright © 2020 Anton Samuilov. All rights reserved.
//

import Foundation
import UIKit
class daysLeftToComplete: UIView {
    
    
}
